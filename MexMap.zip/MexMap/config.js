// API key
const API_KEY = "pk.eyJ1IjoicGFwYW50bGFzIiwiYSI6ImNrOTBsYmxiZDAzMTczZXA2YmpjMnF2a3gifQ.Teoob15TOTmVUjYJf5Efzg";
