// An array of cities and their locations
var cities = [
  {
    name: "Aguascalientes",
    location: [21.8823395, -102.2825928]
  },
  {
    name: "Baja California",
    location: [32.6278114, -115.4544601]
  },
  {
    name: "Baja California Sur",
    location: [24.1443691, -110.300499]
  },
  {
    name: "Campeche",
    location: [19.8438606, -90.5255432]
  },
  {
    name: "Coahuila",
    location: [25.4232101, -101.0053024]
  },  
  {
    name: "Chiapas",
    location: [16.7597294, -93.1130829]
  },
  {
    name: "Chihuahua",
    location: [28.6352806, -106.0888901]
  },
  {
    name: "Ciudad de México",
    location: [19.4284706, -99.1276627]
  },
  {
    name: "Durango",
    location: [24.0203209, -104.6575623]
  },
  {
    name: "Guanajuato",
    location: [21.1290798, -101.6737366]
  },
  {
    name: "Guerrero",
    location: [17.5506001, -99.5057831]
  },
  {
    name: "Hidalgo",
    location: [20.1169701, -98.7332916]
  },
  {
    name: "Jalisco",
    location: [20.6668205, -103.3918228]
  },
  {
    name: "Estado de México",
    location: [19.2878609, -99.6532364]
  },
  {
    name: "Michoacán",
    location: [19.7007809, -101.184433]
  },
  {
    name: "Morelos",
    location: [18.9260998, -99.230751]
  },
  {
    name: "Nayarit",
    location: [21.50951, -104.8956909]
  },
  {
    name: "Nuevo León",
    location: [25.6750698, -100.3184662]
  },
  {
    name: "Oaxaca",
    location: [17.0654202, -96.7236481]
  },
  {
    name: "Puebla",
    location: [19.0379295, -98.2034607]
  },
  {
    name: "Querétaro",
    location: [20.5880604, -100.3880615]
  },
  {
    name: "Quintana Roo",
    location: [21.1742897, -86.8465576]
  },
  {
    name: "San Luis Potosí",
    location: [22.1498203, -100.9791565]
  },
  {
    name: "Sinaloa",
    location: [24.7903194, -107.3878174]
  },
  {
    name: "Sonora",
    location: [29.1026001, -110.9773178]
  },
  {
    name: "Tabasco",
    location: [17.9868908, -92.9302826]
  },
  {
    name: "Tamaulipas",
    location: [23.7417393, -99.1459885]
  },
  {
    name: "Veracruz",
    location: [19.5312405, -96.9158936]
  },
  {
    name: "Yucatán",
    location: [20.9753704, -89.6169586]
  }  
];

// An array which will be used to store created cityMarkers
var cityMarkers = [];

for (var i = 0; i < cities.length; i++) {
  // loop through the cities array, create a new marker, push it to the cityMarkers array
  cityMarkers.push(
    L.marker(cities[i].location).bindPopup("<h1>" + cities[i].name + "</h1>")
  );
}

// Add all the cityMarkers to a new layer group.
// Now we can handle them as one group instead of referencing each individually
var cityLayer = L.layerGroup(cityMarkers);

// Define variables for our tile layers
var light = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.light",
  accessToken: API_KEY
});

var dark = L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
  attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
  maxZoom: 18,
  id: "mapbox.dark",
  accessToken: API_KEY
});

// Only one base layer can be shown at a time
var baseMaps = {
  Light: light,
  Dark: dark
};

// Overlays that may be toggled on or off
var overlayMaps = {
  Cities: cityLayer
};

// Create map object and set default layers
var myMap = L.map("map", {
  center: [19.4284706, -99.1276627],
  zoom: 5,
  layers: [light, cityLayer]
});

// Pass our map layers into our layer control
// Add the layer control to the map
L.control.layers(baseMaps, overlayMaps).addTo(myMap);
